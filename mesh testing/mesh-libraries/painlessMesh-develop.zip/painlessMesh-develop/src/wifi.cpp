#include "arduino/wifi.hpp"
painlessmesh::logger::LogClass Log;
