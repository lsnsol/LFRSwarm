/* 
 * https://github.com/arkhipenko/TaskScheduler/tree/master/examples/Scheduler_example16_Multitab
 */

#include "painlessTaskOptions.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#include <TaskScheduler.h>
#pragma GCC diagnostic pop
